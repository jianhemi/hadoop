Hadoop EC2

NOTE: these scripts have been deprecated. See http://incubator.apache.org/whirr.

This collection of scripts allows you to run Hadoop clusters on Amazon.com's Elastic Compute Cloud (EC2) service described at:

  http://aws.amazon.com/ec2
  
To get help, type the following in a shell:
  
  bin/hadoop-ec2

For full instructions, please visit the Hadoop wiki at:

  http://wiki.apache.org/hadoop/AmazonEC2#AutomatedScripts
